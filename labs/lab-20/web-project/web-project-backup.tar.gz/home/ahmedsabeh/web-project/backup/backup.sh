#!/bin/bash
tar -czvf web-project-backup.tar.gz ~/web-project
echo "Backup completed: web-project-backup.tar.gz"
