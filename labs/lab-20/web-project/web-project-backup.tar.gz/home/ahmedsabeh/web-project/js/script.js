function showMessage() {
    alert("Hello from Lab 20! 🎉 You made it!");
}
